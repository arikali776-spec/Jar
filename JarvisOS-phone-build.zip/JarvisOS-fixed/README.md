# JARVIS Android App (repaired source layout)

This project has been reorganized into a standard Android Gradle project layout. It includes the original voice assistant, online/offline AI integration, wake-word service, and accessibility automation source files.

## Build an APK
1. Install Android Studio (with Android SDK Platform 34 and a compatible JDK).
2. Open this folder (`JarvisOS-fixed`) in Android Studio and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Setup needed for full functionality
- Set a valid Picovoice access key in `app/src/main/java/com/stark/jarvis/JarvisConfig.kt` for wake-word detection.
- Online AI requires the configured API endpoint/key (review `HybridAiBrain.kt`).
- Offline AI requires a compatible on-device model file and sufficient device RAM/storage; it is not bundled in this project.
- Screen automation requires manually enabling the JARVIS accessibility service in Android Settings. Android restricts some actions and permissions; the app cannot silently control every phone feature.
- Microphone, phone, contacts, camera, and notification permissions are sensitive and should be granted only if you want the related feature.

The current build environment did not include the Android SDK or Gradle installation, so an APK could not be compiled and verified here. This ZIP is the repaired source project, not an installable APK.
